-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2022 at 03:33 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `name` varchar(11) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`name`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bookingdetails`
--

CREATE TABLE `bookingdetails` (
  `equipment` varchar(50) NOT NULL,
  `food` varchar(50) NOT NULL,
  `decoration` varchar(50) NOT NULL,
  `flower` varchar(50) NOT NULL,
  `seating` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `bid` int(11) NOT NULL,
  `price` int(50) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookingdetails`
--

INSERT INTO `bookingdetails` (`equipment`, `food`, `decoration`, `flower`, `seating`, `name`, `date`, `bid`, `price`) VALUES
('STAGE,MIKE $ SPEAKER', 'DINNER', 'Normal', 'Normal', 'CHAIR AND SOFA', 'KRISHNENDU A S', '2022-06-01', 1, 2147483647),
('STAGE,MIKE $ SPEAKER', 'LUNCH $ DINNER', 'Normal', 'Normal', 'CHAIR', 'KRISHNENDU A S', '2022-06-02', 2, 2147483647),
('DJ', 'DINNER', 'Normal', 'Normal', 'SOFA', 'Surya S', '2022-06-03', 3, 2147483647),
('STAGE,MIKE $ SPEAKER', 'BREAKFAST', 'None', 'None', 'CHAIR', 'Surya S', '2022-06-04', 4, 2147483647),
('STAGE,MIKE $ SPEAKER', 'LUNCH', 'Normal', 'Normal', 'CHAIR', 'Surya S', '2022-06-05', 5, 2147483647),
('STAGE,MIKE $ SPEAKER', 'BREAKFAST', 'Normal', 'Normal', 'CHAIR AND SOFA', 'KRISHNENDU A S', '2022-06-09', 6, 2147483647),
('DJ_STAGE', 'LUNCH_DINNER', 'Royal', 'Royal', 'CHAIR_AND_SOFA', 'Surya S', '2022-02-13', 44, 60000),
('STAGE_MIKE_SPEAKER', 'LUNCH', 'Normal', 'Normal', 'CHAIR', 'Mubeena Nazar', '2022-06-28', 45, 10000),
('STAGE_MIKE_SPEAKER', 'BREAKFAST', 'Normal', 'Royal', 'CHAIR_AND_SOFA', 'Adeeshaya D', '2022-06-27', 46, 21000),
('STAGE_MIKE_SPEAKER', 'BREAKFAST', 'Normal', 'Normal', 'CHAIR', 'KRISHNENDU A S', '2022-06-27', 47, 10000),
('DJ_STAGE', 'BREAKFAST', 'Normal', 'Normal', 'CHAIR', 'Chandra S', '2022-12-01', 48, 1500),
('STAGE_MIKE_SPEAKER', 'LUNCH', 'Normal', 'Normal', 'CHAIR', '', '2022-06-02', 49, 1500),
('DJ', 'TEA_SNACKS', 'Normal', 'Normal', 'SOFA', 'Chandra S', '2022-04-15', 50, 3000),
('STAGE_MIKE_SPEAKER', 'TEA_SNACKS', 'Normal', 'Normal', 'CHAIR', 'Chandra S', '2022-04-22', 51, 1500);

-- --------------------------------------------------------

--
-- Table structure for table `bookingtable`
--

CREATE TABLE `bookingtable` (
  `name` varchar(20) NOT NULL,
  `etype` varchar(20) NOT NULL,
  `vname` varchar(20) NOT NULL,
  `number` int(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` int(11) DEFAULT NULL,
  `bid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookingtable`
--

INSERT INTO `bookingtable` (`name`, `etype`, `vname`, `number`, `date`, `time`, `status`, `bid`) VALUES
('KRISHNENDU A S', 'wedding', ' Jhargram Raj Palace', 25, '2022-06-01', '12:00:00', 1, 1),
('KRISHNENDU A S', 'wedding', ' Palace Park', 25, '2022-06-02', '12:00:00', 1, 2),
('Surya S', 'wedding', ' Mysore Palace Park', 25, '2022-06-03', '12:00:00', 0, 3),
('Surya S', 'birthdays', ' Leela Hotel', 100, '2022-06-04', '12:00:00', 1, 4),
('Surya S', 'celebrity events', ' Palace Park', 200, '2022-06-05', '12:00:00', 0, 5),
('KRISHNENDU A S', 'wedding', ' Mysore Palace Park', 100, '2022-06-09', '12:00:00', 1, 6),
('Surya S', 'birthdays', ' Palace Park', 200, '2022-02-13', '12:00:00', 1, 18),
('Mubeena Nazar', ' conference', ' Palace Park', 100, '2022-06-28', '12:00:00', 0, 19),
('Adeeshaya D', 'celebrity events', ' Begams Hall', 70, '2022-06-27', '12:00:00', 1, 20),
('KRISHNENDU A S', 'wedding', ' Mysore Palace Park', 100, '2022-06-27', '12:00:00', 1, 21),
('KRISHNENDU A S', 'wedding', ' Palace Park', 70, '2022-06-26', '12:00:00', 0, 22),
('KRISHNENDU A S', 'wedding', ' Mysore Palace Park', 250, '2022-05-01', '12:00:00', 0, 23),
('Chandra S', 'wedding', ' Mysore Palace Park', 15, '2022-04-15', '12:00:00', 1, 26),
('Chandra S', 'wedding', ' Begams Hall', 15, '2022-04-22', '12:00:00', 1, 27);

-- --------------------------------------------------------

--
-- Table structure for table `confirmbookingtable`
--

CREATE TABLE `confirmbookingtable` (
  `name` varchar(20) NOT NULL,
  `etype` varchar(20) NOT NULL,
  `vname` varchar(20) NOT NULL,
  `number` int(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confirmbookingtable`
--

INSERT INTO `confirmbookingtable` (`name`, `etype`, `vname`, `number`, `date`, `time`) VALUES
('', '', '', 0, '0000-00-00', '00:00:00'),
('Arathy', 'wedding', 'tvm', 12, '2022-01-04', '00:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacktable`
--

CREATE TABLE `feedbacktable` (
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `feed` varchar(100) NOT NULL,
  `fimage` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedbacktable`
--

INSERT INTO `feedbacktable` (`name`, `email`, `feed`, `fimage`) VALUES
('Chandra S', 'chandras2000@gmail.com', 'Nice service....I was really impressed by the service provided', 0x706572696e67616d6d616c612e6a7067),
('KRISHNENDU A S', 'krishnenduas20@gmail.com', 'Woww.....', 0x6b6f76616c616d206c65656c6120686f74656c2e6a7067),
('Surya S', 'suryamalus1999@gmail.com', 'very good customer service', 0x426567756d732048616c6c2e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` varchar(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `password1` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `mobile`, `password`, `password1`) VALUES
('', 'KRISHNENDU A S', 'krishnenduas20@gmail', '9988776655', 'Kichu@19', 'Kichu@19'),
('CS2', 'Mubeena Nazar', 'mube@1999', '2147483647', 'mube@19', 'mube@19'),
('CS3', 'Surya S', 'suryamalus1999@gmail', '9988776655', 'surya', 'surya'),
('CS4', 'Rubi R', 'rubi1999@gmail.com', '9988776444', 'Rubi@199', 'Rubi@199'),
('CS5', 'Elizabeth Kuriakose', 'eli1999@gmail.com', '9947207355', 'Elizabeth@1999', 'Elizabeth@1999'),
('CS6', 'Adeeshaya D', 'adee1999@gmail.com', '9807654330', 'Adeeshaya@1999', 'Adeeshaya@1999'),
('CS7', 'Chandra S', 'chandras2000@gmail.c', '9988776651', 'Kichu@123', 'Kichu@123'),
('CS8', 'Theertha T', 'theerthat1999@gmail.', '9807654228', 'Te2@1234', 'Te2@1234');

-- --------------------------------------------------------

--
-- Table structure for table `venuetable`
--

CREATE TABLE `venuetable` (
  `vid` varchar(20) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `vamount` int(10) NOT NULL,
  `vaddress` varchar(50) NOT NULL,
  `vimage` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venuetable`
--

INSERT INTO `venuetable` (`vid`, `vname`, `vamount`, `vaddress`, `vimage`) VALUES
('VE1', ' Palace Park', 20000, 'Palace Park,Washington', 0x50616c616365205061726b2c2057617368696e67746f6e2e6a7067),
('VE2', ' Mysore Palace Park', 30000, 'Palace Park, Mysore', 0x4d79736f72652050616c616365205061726b2e6a7067),
('VE3', ' Jhargram Raj Palace', 40000, 'Jhargram Raj Palace,Kolkata,India', 0x4a6861726772616d2052616a2050616c6163652e6a7067),
('VE5', ' Begams Hall', 50000, 'Begams Hall, Srinagar, India', 0x426567756d732048616c6c2e6a7067),
('VE6', ' Leela Hotel', 50000, 'Kovalam Leela Hotel', 0x6b6f76616c616d206c65656c6120686f74656c2e6a7067),
('VE7', ' Peringammala', 24000, 'Peringammala Eduva', 0x706572696e67616d6d616c612e6a7067);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookingdetails`
--
ALTER TABLE `bookingdetails`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `bookingtable`
--
ALTER TABLE `bookingtable`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `confirmbookingtable`
--
ALTER TABLE `confirmbookingtable`
  ADD PRIMARY KEY (`name`,`date`);

--
-- Indexes for table `feedbacktable`
--
ALTER TABLE `feedbacktable`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `venuetable`
--
ALTER TABLE `venuetable`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookingdetails`
--
ALTER TABLE `bookingdetails`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `bookingtable`
--
ALTER TABLE `bookingtable`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
